import json, random, pygame, os, platform
from pygame.locals import *


pygame.init()
width, height = 800, 600
x, y =  pygame.display.Info().current_w, pygame.display.Info().current_h
screen_width = int((x // 2) - (width // 2))
screen_height = int((y // 2) - (height // 2))
os.environ["SDL_VIDEO_WINDOW_POS"] = "%d,%d" % (screen_width, screen_height)
pygame.display.set_caption("APPRENDRE LE BRAILLE FRANÇAIS")
pygame.mouse.set_cursor(*pygame.cursors.broken_x)
window = pygame.display.set_mode((width, height), pygame.HWSURFACE | pygame.HWACCEL)
icon = pygame.image.load("lib/img/icon.png")
if platform.system() == "Windows":
	pygame.display.set_icon(icon)

white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)
green = (0, 255, 0)
letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
game = True
score = 0
scoreTemporaire = 1

def functionStart(color):
	global matrix, autorisations, window, matrixTwo
	autorisations = [True, True, True, True, True, True]
	matrix = [["", ""], ["", ""], ["", ""]]
	window.fill(white)
	rectangleOne = pygame.Rect(10, 10, 350, 500)
	pygame.draw.rect(window, color, rectangleOne, 5)
	img = pygame.image.load("lib/img/1.png")
	window.blit(img, (50, 50))
	window.blit(img, (200, 50))
	window.blit(img, (50, 200))
	window.blit(img, (200, 200))
	window.blit(img, (50, 350))
	window.blit(img, (200, 350))
	img = pygame.image.load("lib/img/button.png")
	rectangleLetter = pygame.Rect(500, 200, 118, 100)
	pygame.draw.rect(window, color, rectangleLetter, 5)
	window.blit(img, (500, 400))
	with open('lib/json/file/letter.json') as jsonLetter:
		letter = json.load(jsonLetter)
		r = random.randint(0, len(letters)-1)
		matrixTwo = letter[letters[r]]
		police = pygame.font.SysFont("verdana", 50)
		message = police.render("{}".format(letters[r]), False, black)
		window.blit(message, (535, 210))

def functionScore(color):
	global score
	police = pygame.font.SysFont("verdana", 20)
	message = police.render("SCORE : {}".format(score), False, color)
	window.blit(message, (10, 550))
	pygame.display.update()

functionStart(black)
functionScore(black)



while game:
	def function(x, y, one, two, value):
		global matrix, autorisations, window
		if autorisations[value] == True:
			window.blit(pygame.image.load("lib/img/2.png"), (x, y))
			pygame.display.update()
			autorisations[value] = False
			matrix[one][two] = "o"
			return "changé !"
		if autorisations[value] == False:
			window.blit(pygame.image.load("lib/img/1.png"), (x, y))
			pygame.display.update()
			autorisations[value] = True
			matrix[one][two] = ""
			return "changé !"
	def function_click_one():
		x, y = pygame.mouse.get_pos()
		if 50 < x < 150 and 50 < y < 150: function(50, 50, 0, 0, 0)
		if 200 < x < 300 and 50 < y < 150: function(200, 50, 0, 1, 1)
		if 50 < x < 150 and 200 < y < 300: function(50, 200, 1, 0, 2)
		if 200 < x < 300 and 200 < y < 300: function(200, 200, 1, 1, 3)
		if 50 < x < 150 and 350 < y < 450: function(50, 350, 2, 0, 4)
		if 200 < x < 300 and 350 < y < 450: function(200, 350, 2, 1, 5)

	def function_win():
		global score, scoreTemporaire
		if matrix == matrixTwo:
			if scoreTemporaire == 1:
				score += 2
			if scoreTemporaire == 0:
				score += 1
			scoreTemporaire = 1
			functionStart(green)
			functionScore(green)
		else:
			scoreTemporaire = 0
			functionStart(red)
			functionScore(red)
	def function_click_two():
		x, y = pygame.mouse.get_pos()
		if 500 < x < 618 and 400 < y < 442:
			function_win()
	def function_three():
		function_win()
		

	for event in pygame.event.get():
		if event.type == 12:
			game = False 
			pygame.quit()
		if event.type == 2 and pygame.key.get_pressed()[K_RETURN]:
			function_three()
		if event.type == 6:
			function_click_one()
			function_click_two()
		if game == True:
			pygame.display.update()
